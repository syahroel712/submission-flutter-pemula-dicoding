package com.example.soccer_shoes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
